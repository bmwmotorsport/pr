import { useEffect, useState } from "react";
import { getDoctors } from "../api/doctor";

function DoctorList() {
  const [doctors, setDoctors] = useState([]);

  useEffect(() => {
    getDoctors().then((res) => setDoctors(res.data));
  }, []);

  return (
    <div>
      <h2>Doctor List</h2>
      <ul>
        {doctors.map((doc) => (
          <li key={doc.id}>{doc.user.username} - {doc.specialization}</li>
        ))}
      </ul>
    </div>
  );
}

export default DoctorList;
