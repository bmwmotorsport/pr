import axios from 'axios';
export const getDoctors = () => axios.get('http://localhost:8000/api/doctors/');
