import DoctorList from './components/DoctorList';

function App() {
  return (
    <div>
      <h1>Hospital Management System</h1>
      <DoctorList />
    </div>
  );
}

export default App;
