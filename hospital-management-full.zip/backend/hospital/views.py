from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import Doctor
from .serializers import DoctorSerializer
import requests
from bs4 import BeautifulSoup

@api_view(['GET'])
def get_doctors(request):
    doctors = Doctor.objects.all()
    serializer = DoctorSerializer(doctors, many=True)
    return Response(serializer.data)

@api_view(['GET'])
def get_medicine_info(request):
    name = request.GET.get('name', '')
    if not name:
        return Response({"error": "No medicine name provided"})
    url = f"https://www.drugs.com/search.php?searchterm={name}"
    soup = BeautifulSoup(requests.get(url).content, "html.parser")
    result = soup.find("ul", class_="ddc-list-column-2")
    if result:
        link = "https://www.drugs.com" + result.find("a")["href"]
        page = requests.get(link)
        desc = BeautifulSoup(page.content, "html.parser").find("div", class_="contentBox")
        return Response({"info": desc.text.strip()[:500]})
    return Response({"info": "No data found"})
