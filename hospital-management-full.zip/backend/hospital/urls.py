from django.urls import path
from .views import get_doctors, get_medicine_info

urlpatterns = [
    path('doctors/', get_doctors),
    path('medicine/', get_medicine_info),
]
